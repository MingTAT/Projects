package com.cybeacon.base;

/**
 * @author Ming
 */

public abstract class BaseView implements IBaseView {
}
