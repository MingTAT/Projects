package com.cybeacon.home.view;

import com.cybeacon.base.IBaseView;

/**
 * @author Ming
 */
public interface HomeView extends IBaseView{
}
