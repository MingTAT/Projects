package com.cybeacon.professor.course_detail;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.cybeacon.R;
import com.cybeacon.base.BaseMVPActivity;

/**
 * @author Ming
 */

public class CourseDetail extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_professor_course_detail_layout);
    }
}
