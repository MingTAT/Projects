package com.cybeacon.constants;

/**
 * @author Ming
 */

public class IntentExtras {
    public static String UserType = "userType";
}
