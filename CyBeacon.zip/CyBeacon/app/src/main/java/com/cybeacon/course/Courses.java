package com.cybeacon.course;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by Sam on 3/28/2017.
 */
public class Courses {

    public String UUID;
    public String CourseName;
    public ArrayList<ClassInfo> Classes;
    public String URL;

}
