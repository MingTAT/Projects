package com.cybeacon.register.view;

import com.cybeacon.base.IBaseView;

/**
 * Created by Ming on 2017/4/15 0015.
 */

public interface RegisterView extends IBaseView{

    void registerSuccess(String response);
}
