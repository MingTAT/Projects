package com.cybeacon.constants;

/**
 * @author Ming
 */

public class ErrorCode {
    public static final int CODE_ERROR = 50001;
}
