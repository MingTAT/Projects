package com.cybeacon.course;

import java.util.ArrayList;

/**
 * Created by Sam on 3/28/2017.
 */
public class ClassInfo {

    public String CourseName;
    public String ClassName;
    public String URL;

    public String getCourseName()
    {
        return CourseName;
    }

    public String getClassName()
    {
        return ClassName;
    }

    public String getURL()
    {
        return URL;
    }

}