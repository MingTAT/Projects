package com.ttu.ttu;

/**
 * @author Ming
 */

public class Config {
    /** 重新调整格式*/
    public static final String IBEACON_FORMAT = "m:2-3=0215,i:4-19,i:20-21,i:22-23,p:24-24";
    /** 设置兴趣UUID*/
    public static final String FILTER_UUID = "7b44b47b-52a1-5381-90c2-f09b6838c5d4";
}
