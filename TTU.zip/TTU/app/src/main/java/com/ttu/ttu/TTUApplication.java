package com.ttu.ttu;

import android.app.Application;
import android.util.Log;


/**
 *
 *
 * @author Ming
 *
 *
 */

public class TTUApplication extends Application {

    private static final String TAG = "TTUApplication";


    @Override
    public void onCreate() {
        super.onCreate();
    }

}
